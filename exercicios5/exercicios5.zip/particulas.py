'''
Reaproveitando a definição já existente da bolinha,
crie uma animação com várias bolinhas com direções e velocidades
aleatórias que colidem entre si
'''
from bolinha import *
import random

REDONDEZAS= 20

BOLA_1 = Bola(random.randrange(LIMITE_ESQUERDO,LIMITE_DIREITO),random.randrange(LIMITE_CIMA,LIMITE_BAIXO),random.randrange(2,5),random.randrange(2,5))
BOLA_2 = Bola(random.randrange(LIMITE_ESQUERDO,LIMITE_DIREITO),random.randrange(LIMITE_CIMA,LIMITE_BAIXO),random.randrange(2,5),random.randrange(2,5))
BOLA_3 = Bola(random.randrange(LIMITE_ESQUERDO,LIMITE_DIREITO),random.randrange(LIMITE_CIMA,LIMITE_BAIXO),random.randrange(2,5),random.randrange(2,5))
BOLA_4 = Bola(random.randrange(LIMITE_ESQUERDO,LIMITE_DIREITO),random.randrange(LIMITE_CIMA,LIMITE_BAIXO),random.randrange(2,5),random.randrange(2,5))
BOLA_5 = Bola(random.randrange(LIMITE_ESQUERDO,LIMITE_DIREITO),random.randrange(LIMITE_CIMA,LIMITE_BAIXO),random.randrange(2,5),random.randrange(2,5))

Jogo = definir_estrutura("Jogo", "bola1, bola2, bola3, bola4, bola5")
''' Jogo pode ser formado assim: Jogo(Bola, Bola, Bola, Bola, Bola)
interp. representa o jogo com varias bolinha quicantes.
'''
#EXEMPLOS:
JOGO_1 = Jogo(BOLA_1, BOLA_2, BOLA_3, BOLA_4, BOLA_5)
JOGO_2 = Jogo(BOLA_3, BOLA_5, BOLA_1, BOLA_2, BOLA_4)

#TEMPLATE
'''
def fn_para_jogo(jogo):
    ... jogo.bola1
        jogo.bola2
        ...
'''
def fn_jogo(jogo):
    # TODO // fazer as bolas quicarem quando se encontrarem
    return Jogo(mover_bola(jogo.bola1),mover_bola(jogo.bola2),mover_bola(jogo.bola3),mover_bola(jogo.bola4),mover_bola(jogo.bola5))

def desenha(jogo):
    desenha_b(jogo.bola1)
    desenha_b(jogo.bola2)
    desenha_b(jogo.bola3)
    desenha_b(jogo.bola4)
    desenha_b(jogo.bola5)