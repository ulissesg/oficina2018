from foguete import *

def main(f):
    big_bang(f, frequencia=FREQUENCIA,
             quando_tick=mover, #nao consegui usar a_cada_tick.
             desenhar=desenha,
             )


main(100)